lista2 = [1, 3, 5, 7, 9, 2, 4, 6, 8, 10]
lista2.sort()
print(lista2)
print(lista2[-1])
print(lista2[0])
def somalista(elementos):
    soma = 0
    for i in elementos:
        soma = soma + i
    return soma

print(somalista(lista2))
