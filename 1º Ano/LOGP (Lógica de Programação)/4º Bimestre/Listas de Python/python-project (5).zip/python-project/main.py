lista1 = [1,2,3,4,5,6,7,8,9,10]
lista1.append(11)
lista1.remove(5)
lista1.reverse()
print(lista1)
