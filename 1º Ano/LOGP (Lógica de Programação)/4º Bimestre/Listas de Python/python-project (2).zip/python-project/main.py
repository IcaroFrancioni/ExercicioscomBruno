numeros = (10, 20, 30, 40, 50)
print(numeros[2])
numeros2 = []

flag = "20"
i = 0
for i in range(len(numeros)):
  if(flag==numeros[i]):
    print( "Encontrado na posição", i)
numeros2 = numeros
print(numeros2)
