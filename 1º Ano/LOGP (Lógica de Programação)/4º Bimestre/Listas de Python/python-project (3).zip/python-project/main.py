cores = ('vermelho', 'azul', 'verde', 'amarelo','preto')
cores2 = ()

azull=cores.count("azul")
print(azull)
flag = "verde"
i = 0
for i in range(len(cores)):
  if(flag==cores[i]):
    print( "Encontrado na posição", i)
cores2 = cores + ("branco", "preto")
print(cores2)
