numeros = ['Ana', 'Carlos', 'Beatriz', 'Daniel','Elisa']

aksjk=numeros.count("Ana")
print(aksjk)
flag = "Carlos"
i = 0
for i in range(len(numeros)):
  if(flag==numeros[i]):
    print( "Encontrado na posição", i)
numeros[2]= "Bruna"
print(numeros)
