trabalho = {'nome': 'João',
'idade': 25, 'cidade': 'São Paulo'}
trabalho['profissão'] = 'Engenheiro'
trabalho.pop('cidade')
print(trabalho)
